
package Control;

import gui.Diseño;

public class Main {
    
    public static void main(String args[]){
        Controlador.getInstance();
        Diseño gui = new Diseño();
    }
}

package datos;

import Control.Observator;

public class Gestion implements Observator{
    
    private Usuario[] usuarios;
    private Administrador[] administradores;
    private Producto[] productos;
    
    
    public Gestion(){
        
        obtenerUsuarios();
        obtenerAdministrador();
        obtenerProductos();
    }

    private void obtenerUsuarios() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void obtenerAdministrador() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void obtenerProductos() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
        
    public boolean login(String usuario, String passwd){
        for (int i=0; i<usuarios.length; i++){
            if(usuarios[i].getNombre().equalsIgnoreCase(usuario) && usuarios[i].getNombre().equals(passwd)){
                //notifyLogin();
                return true;
            }
            if(administradores[i].getNombre().equalsIgnoreCase(usuario) && administradores[i].getNombre().equals(passwd)){
                //notifyLogin();
                return true;
            }
        }
        return false;
    }

    @Override
    public void addObservador(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeObservador(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void notifyLogin() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void notifyCompra() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void notifyModProducto() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

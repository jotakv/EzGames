package datos;

public class Administrador extends Persona{
    
    public Administrador(String id, String passwd, String name, String apellido, String correo) {
        super(id, passwd, name, apellido, correo);
    }
    
}

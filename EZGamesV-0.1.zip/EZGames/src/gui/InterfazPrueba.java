/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.time.Clock;

/**
 *
 * @author usuario_local
 */
public class InterfazPrueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Diseño diseno = new Diseño();
        diseno.setVisible(true);
    }
    
}

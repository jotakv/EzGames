
package control;

import gui.Diseno;

public class Main {
    
    public static void main(String args[]){
    	Controlador.getInstance();
    	Diseno gui = new Diseno();
       
    }
}
